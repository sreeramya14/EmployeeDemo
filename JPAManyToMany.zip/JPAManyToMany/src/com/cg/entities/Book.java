package com.cg.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;




@Entity
@Table(name="book_tbl")
public class Book {
      
	public Book() {
		super();
	}
	/**
	 * 
	 */
	@Id
	@Column(name = "book_id")
	private int id;
	
	
	@Column
	private String title;
	@Column
	private double price;
	
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}
	@ManyToMany(mappedBy="book")
	private Set<Author> author = new HashSet<Author>();
	
	
	
	
	
	public Set<Author> getAuthor() {
		return author;
	}
	
	
	public void setAuthor(Set<Author> author) {
		this.author = author;
	}
	
	
}
