package com.cg.entities;



import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class Client {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entitym = factory.createEntityManager();
		entitym.getTransaction().begin();

		// first define few products before we place order

		Book bk = new Book();
		bk.setId(1);
		bk.setTitle("Java Programming");
		bk.setPrice(450);

		Book bk1 = new Book();
		bk1.setId(2);
		bk1.setTitle("C Programming");
		bk1.setPrice(350);


		Book bk2 = new Book();
		bk2.setId(3);
		bk2.setTitle("C++ Programming");
		bk2.setPrice(650);



		// now define first order and add few products in it
		Author auth = new Author();
		auth.setId(101);
		auth.setName("Balguruswamy");

		
		
	
		// now define second order and add few products in it
		Author auth1 = new Author();
		auth1.setId(102);
		auth1.setName("Ramesh");

		auth1.addBook(bk);
		auth1.addBook(bk1);
		auth1.addBook(bk2);
		
		auth.addBook(bk);
		auth.addBook(bk1);
		auth.addBook(bk2);
	
		
		

		// save orders using entity manager

		entitym.persist(auth);
		entitym.persist(auth1);
		
		
		entitym.getTransaction().commit();
		System.out.println("Inserted");
		entitym.close();
		factory.close();
	}

	}


