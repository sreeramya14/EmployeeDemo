package com.test;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;




@Aspect
public class AccountAspect {
	
	
	/*@Before("adviceToAll()")
	public void beforeAdvice()
	{
		System.out.println("before advice called");
	}*/
	
	/*@Pointcut("execution(* com.test.* .*())")
	public void adviceToAll()
	{
		
	}*/
	/*@Around("adviceToAll()")
	public void beforeAdvice(ProceedingJoinPoint pjp) throws Throwable 
	{
		System.out.println("before advice called");
		long start=System.currentTimeMillis();
		Object obj=pjp.proceed();
		long stop =System.currentTimeMillis();
		System.out.println("After advice called");
		System.out.println("Time = "+(stop-start));
	}*/
	
	

	
	public void beforeAdvice() 
	{
		System.out.println("before advice called");
		
	}
	

}
