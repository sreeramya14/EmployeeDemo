package com.test;

public class Account {

	
	public String withdraw()
	{
		System.out.println(" Account withdraw called");
		return null;
	}
}
