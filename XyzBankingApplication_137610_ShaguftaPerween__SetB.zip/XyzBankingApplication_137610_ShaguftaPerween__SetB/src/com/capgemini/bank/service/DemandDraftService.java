package com.capgemini.bank.service;


import com.capgemini.bank.Exception.BankException;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;


public class DemandDraftService implements IDemandDraftService
{
	//Loose Coupling
	IDemandDraftDAO demandDAO;
	
	public DemandDraftService()
	{
		 //Associating Service and DAO
		demandDAO= new DemandDraftDAO();
		
	}

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws BankException
	{
		
		return demandDAO.addDemandDraftDetails(demandDraft);
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws BankException 
	{
		
		return demandDAO.getDemandDraftDetails(transactionId);
	}

}
