package com.capgemini.bank.dao;

import com.capgemini.bank.Exception.BankException;
import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftDAO
{
	int addDemandDraftDetails(DemandDraft demandDraft) throws BankException;
	DemandDraft getDemandDraftDetails(int transactionId) throws BankException;
}
