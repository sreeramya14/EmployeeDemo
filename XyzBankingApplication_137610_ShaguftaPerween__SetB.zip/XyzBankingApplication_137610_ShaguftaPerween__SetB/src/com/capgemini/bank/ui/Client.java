package com.capgemini.bank.ui;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.Exception.BankException;
import com.capgemini.bank.bean.DemandDraft;

import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bank.util.ValidationUtil;


interface MenuChoice
{
	public static int ADD_DEMAND_DRAFT=1;
	public static int GET_DEMAND_DRAFT=2;
	public static int EXIT_APPLICATION=3;
}

public class Client implements MenuChoice {
	
	//private DemandDraftDAO demandDraftDao;
	private IDemandDraftService demandDraftService;
	public Client()
	{
		//Loose Coupling
		demandDraftService = new DemandDraftService();
	}
	

	public void menu() {
		
		Scanner console=new Scanner(System.in);
		
		System.out.println("1. Enter Demand Draft Details\n2.Print Demand Draft \n3.Exit");
		System.out.println("Enter your choice");
		
		int choice=console.nextInt();
		
		switch(choice)
		{
		case ADD_DEMAND_DRAFT:	addDemandDraft(); break;
		
		case GET_DEMAND_DRAFT:	getDemandDraft(); break;
			
		case EXIT_APPLICATION:	System.out.println("GoodBye"); System.exit(0); break;
		
		default: System.out.println("Invalid Option!. Please try again"); menu();break;
		
		}
	}

	private void getDemandDraft() {
		
		 Scanner sc = new Scanner(System.in);

		int id = 0;

		//do {
		System.out.println("Enter TransactionId");
		id = sc.nextInt();
		//} while (.isIdInvalid(id));

		
		try {

			DemandDraft demandDraft = demandDraftService.getDemandDraftDetails(id);
			
			int total_amount=demandDraft.getCommission()+demandDraft.getAmount();
			System.out.println("Name of the bank:XYZ");
			System.out.println("DD Amount:"+demandDraft.getAmount());
			System.out.println("DD Commission:"+demandDraft.getCommission());
			System.out.println("Total Amount:"+total_amount);
			System.out.println("Transaction Date:"+demandDraft.getDate());
			System.out.println("Remarks: "+demandDraft.getDescription());
		}

		catch (Exception e) {
				System.out.println("Something went wrong Reason: "+e.getMessage());
		}

		 
		
	}


	private void addDemandDraft() {
		
		Scanner console=new Scanner(System.in);
		
		String name=null;
		do{
		System.out.println("Enter Customer name");
		 name=console.nextLine();
		}while(ValidationUtil.isNameInvalid(name));
		
		String phone=null;
		do
		{
			System.out.println("Enter Customer phone no");
			phone=console.nextLine();
			
		}while(ValidationUtil.isphoneInvalid(phone));
		
		String favor=null;
		do
		{
			System.out.println("In favor of");
			favor=console.nextLine();
			
		}while(ValidationUtil.isfavorInvalid(favor));
		
		int ddAmount=0;
		do
		{
			System.out.println("Enter Demand Draft amount(in Rs");
			ddAmount=Integer.parseInt(console.nextLine());
		}while(ValidationUtil.isddAmountInvalid(ddAmount));
		
		String description=null;
		do
		{
			System.out.println("Enter Remarks");
			description=console.next();
			description +=console.nextLine();
		}while(ValidationUtil.isRemarksInvalid(description));
		
		//int ddCommission=demandDraftDao.generateCommission();
		
		LocalDate d1=LocalDate.now();
		//Creating bean to pass the service
		//DemandDraft demand = new DemandDraft(name, favor, phNo, amount, commission, desc);

		int commission=getCommission(ddAmount);
		
		DemandDraft demandDraft=new DemandDraft(name,favor,phone,ddAmount,commission,description);
		//passing to service
		try
		{
			int id=demandDraftService.addDemandDraftDetails(demandDraft);
			System.out.println("Your Demand Draft request has been successfully registered along with the transaction id "+id);
			
		}catch(Exception e)
		{
			System.out.println("Something went wrong while trying to add Demand draft Details. Reason:" +e.getMessage());
		}
	}

	private int getCommission(int ddAmount) {
		int commission=0;
		if (ddAmount <= 5000)
			commission = 10;
		else if (ddAmount > 5000 && ddAmount <= 10000)
			commission = 41;
		else if (ddAmount > 10000 && ddAmount <= 100000)
			commission = 51;
		else if (ddAmount > 100000)
			commission = 306;
		return commission;
	}

	public static void main(String[] args) {
		
		
		 PropertyConfigurator.configure("log4j.properties");
		Client ui=new Client();
		
		while(true){
			ui.menu();
		}
	}
		 
	

}
