package com.capgemini.bank.test;
import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;



public class TestDemandDraftDAO {

	static IDemandDraftService demandDraftService;
	
	
	 @BeforeClass
	public static void init()
	{
		demandDraftService=new DemandDraftService();
	}
	
	@AfterClass
	public static void destroy()
	{
		demandDraftService=null;
		System.gc();
	}
	
	
	
	 public void testAddDemandDraft() {
		
		DemandDraft dd=new DemandDraft("Test","Test","Test",30000,1000,"Test");
		int id=0;
		
		try
		{
			id=demandDraftService.addDemandDraftDetails(dd);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		assertNotEquals(0,id);
	}
	
	 
	 
	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
