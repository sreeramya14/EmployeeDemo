package com.capgemini.tcc.exception;

public class PatientException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6680031530494668603L;
	
	public PatientException()
	{
		super();
	}
	
	public PatientException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
