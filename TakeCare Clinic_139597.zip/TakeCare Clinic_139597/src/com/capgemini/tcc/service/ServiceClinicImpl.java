package com.capgemini.tcc.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.tcc.bean.ClinicBean;
import com.capgemini.tcc.dao.ClinicDAO;
import com.capgemini.tcc.dao.ClinicDAOImpl;
import com.capgemini.tcc.exception.PatientException;



public class ServiceClinicImpl implements IServiceClinic {

	ClinicDAO clinicDAO = new ClinicDAOImpl();
	
	public ServiceClinicImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String insertPatientDetails(ClinicBean clinicBean)
			throws PatientException {
		
           String Seq=null;
		
		  ClinicDAO clinicDAO=new ClinicDAOImpl();
		
          Seq=clinicDAO.insertEmployee(clinicBean);
		
		return Seq;
	}

	@Override
	public List<ClinicBean> search(int patientid) throws PatientException {
		
		List<ClinicBean> patientList = clinicDAO.search(patientid);
		
		return patientList;
	}

	public boolean isValidName(String name) throws PatientException {
		
			
			boolean isValid=false;
			
			String pattern="[A-Z]{1}[a-z ]{0,19}";
			
			Pattern ptn=Pattern.compile(pattern);
			
			Matcher matcher=ptn.matcher(name);
			isValid=matcher.matches();
			
			if(!isValid)
				throw new PatientException("Invalid Name");
			
			return isValid;
			
		
	}
	public boolean isValidAge(int age) throws PatientException {
		
		
        boolean isValid=false;
		
		if(age>0)
			isValid=true;
		
		if(!isValid)
			throw new PatientException("Age Must Be Positive");
		
		return isValid;
		
	
}

	public boolean isValidphone(String phone) throws PatientException {
		
		boolean isValid = false;

		String pattern = "[\\d]{10}";

		Pattern ptn=Pattern.compile(pattern);
        Matcher matcher= ptn.matcher(phone);
		isValid = matcher.matches();
		if(!isValid){
			throw new PatientException("Phone number must contain atleast 10 digits");
		}

		return isValid;
	}


}
