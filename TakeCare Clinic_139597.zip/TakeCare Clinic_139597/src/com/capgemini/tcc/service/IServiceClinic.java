package com.capgemini.tcc.service;

import java.util.List;

import com.capgemini.tcc.bean.ClinicBean;
import com.capgemini.tcc.exception.PatientException;

public interface IServiceClinic {
	
	public String insertPatientDetails(ClinicBean clinicBean)
			throws PatientException;
	
	public List<ClinicBean> search(final int patientid)
			throws PatientException;
			
}
