package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.tcc.bean.ClinicBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.util.DBConnection;

public class ClinicDAOImpl implements ClinicDAO{

	public ClinicDAOImpl() {
		
	}
	@Override
	public String insertEmployee(ClinicBean clinicBean)
			throws PatientException {
		int records=0;
		ResultSet resultSet = null;
		String patientId=null;
		
		try(Connection connPatientDetails = DBConnection.getInstance().getConnection();)	
		{
				PreparedStatement preparedStatement=
				connPatientDetails.prepareStatement(QuerryMapperClinic.INSERT_PATIENT);
		
				java.sql.Date consultation_Date=new Date(new java.util.Date().getTime());
				
			
			
			preparedStatement.setString(1, clinicBean.getPatient_Name());
			preparedStatement.setInt(2,clinicBean.getAge());
			preparedStatement.setString(3, clinicBean.getPhone());
			preparedStatement.setString(4, clinicBean.getDescription());
			preparedStatement.setDate(5, consultation_Date);
			
			
			records=preparedStatement.executeUpdate();
			
			preparedStatement = connPatientDetails.prepareStatement(QuerryMapperClinic.PATIENTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();
			
			if(resultSet.next())
			{
				patientId=resultSet.getString(1);
						
			}
	
			if(records==0)
			{
				throw new PatientException("Inserting Patient details failed ");

			}
			else
			{
				return patientId;
			}
			
		}
		catch(SQLException sqlEx)
		{
			throw new PatientException(sqlEx.getMessage());
		}
		
		
	}

	@Override
	public List<ClinicBean> search(int patientid) throws PatientException {
		List<ClinicBean> patientList = new ArrayList<ClinicBean>();
		try(Connection connemp = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=connemp.prepareStatement(QuerryMapperClinic.SEARCH_PATIENT);
							
				){
				preparedStatement.setInt(1, patientid);
			    ResultSet rsemps = preparedStatement.executeQuery();
				
			    while(rsemps.next()){
			    	ClinicBean emp = new ClinicBean();
				emp.setPatient_Id(rsemps.getInt("patient_id"));
				emp.setPatient_Name(rsemps.getString("patient_name"));
				emp.setAge(rsemps.getInt("age"));
				emp.setPhone(rsemps.getString("phone"));
				emp.setDescription(rsemps.getString("description"));
				emp.setConsultation_Date(rsemps.getDate("consultation_date"));
				
				patientList.add(emp);
			}
				if(patientList.size()==0){
					throw new PatientException("There is no patient with this ID");
				}
		}catch(SQLException sqlEx)
		{
			throw new PatientException(sqlEx.getMessage());
		}
		return patientList;
	}

}
