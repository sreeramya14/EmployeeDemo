package com.capgemini.tcc.dao;

public interface QuerryMapperClinic {
	public static final String INSERT_PATIENT=
			"INSERT INTO Patient VALUES(Patient_Id_Seq.nextVal,?,?,?,?,?)";

	
	public static final String PATIENTID_QUERY_SEQUENCE=
			"SELECT Patient_Id_Seq.CURRVAL FROM DUAL";
	
	public static final String SEARCH_PATIENT = 
			"SELECT patient_id ,patient_name ,age ,phone ,description ,consultation_date FROM Patient WHERE patient_id=?";
}

