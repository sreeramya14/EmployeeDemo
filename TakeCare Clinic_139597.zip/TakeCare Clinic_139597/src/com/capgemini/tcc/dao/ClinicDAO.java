package com.capgemini.tcc.dao;

import java.util.List;

import com.capgemini.tcc.bean.ClinicBean;
import com.capgemini.tcc.exception.PatientException;

public interface ClinicDAO {
	public String insertEmployee(final ClinicBean clinicBean) 
			throws PatientException;
	
	public List<ClinicBean> search(final int empid)
			throws PatientException;
			
}
