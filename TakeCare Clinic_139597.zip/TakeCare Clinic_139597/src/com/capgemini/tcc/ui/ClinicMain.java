package com.capgemini.tcc.ui;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.ClinicBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.ServiceClinicImpl;




public class ClinicMain {
	private static Logger logger=Logger.getRootLogger();
	public static void main(String[] args) {
		
		PropertyConfigurator.configure("resources//log4j.properties");

		boolean isInProcess=true;
		boolean isValid=false;
		
		byte choice=0;
		
		String patientId=null;
		int patientid = 0;
		String name=null;
		int age=0;
		String phone=null;
		String description=null;
	
		java.sql.Date consultation_Date=new Date(new java.util.Date().getTime());
		
		Scanner sc=new Scanner(System.in);
		
		ServiceClinicImpl patientService=new ServiceClinicImpl();
		
		ClinicBean clinicBean=null;
		List<ClinicBean>patientList=null;
		
		while(isInProcess)
		{
			System.out.println("1) Add patient Information");
			System.out.println("2) Search patient by Id");
			System.out.println("0) Exit");
			
			choice=Byte.parseByte(sc.nextLine());
			
			switch(choice){
			case 1:
				
				while(!isValid)
				{
					try{
						System.out.println("Enter Patient name: ");
						name=sc.nextLine();
						
						isValid=patientService.isValidName(name);
						
					}catch(PatientException mpe){
						
						logger.error("Invalid name: "+name);
						System.err.println("Invalid name: "+name);
						isValid=false;
					}
				}

				isValid=false;
				while(!isValid)
				{
					try{
						System.out.println("Enter patient Age: ");
						age=Integer.parseInt(sc.nextLine());
						
						isValid=patientService.isValidAge(age);
						
					}catch(PatientException mpe){
						
						logger.error("Invalid age: "+age);
						System.err.println("Invalid age: "+age);
						isValid=false;
					}
				}
				
				isValid=false;
				while(!isValid)
				{
					try{
						System.out.println("Enter Patient Phone number: ");
						phone=sc.nextLine();
						
						isValid=patientService.isValidphone(phone);
						
					}catch(PatientException mpe){
						
						logger.error("Invalid phone no: "+phone);
						System.err.println("Invalid phone no: "+phone);
						isValid=false;
					}
				}
				
				System.out.println("Enter Description: ");
				description=sc.nextLine();
				
						
				clinicBean=new ClinicBean(patientid,name,age,phone,description,consultation_Date);
				try{
					patientId=patientService.insertPatientDetails(clinicBean);
					
					if(patientId!=null)
						System.out.println("Inserted Successfully! Patient Id is: "+patientId);
					
				}catch(PatientException e){
					logger.error(e.getMessage());
				}
				
				break;
			
			case 2:
				System.out.println("Enter patient id: ");
				patientid= Integer.parseInt(sc.nextLine());
				
				try{
				patientList = patientService.search(patientid);
				if (patientList!=null) {
					for (ClinicBean clinicbean : patientList){
						System.out.println(clinicbean);
					}
				} else {
					System.out.println("There is no patient with this ID");
				}	
				
					System.out.println("====================================================================");
				}catch(PatientException e){
					System.err.print("There is no patient with this ID");
					logger.error(e.getMessage());
				}

			case 0:
				
				isInProcess=false;
				break;
				
			default:
				
				System.out.println("Invalid input");
				logger.error("Invalid input: "+choice);
				System.err.println("Invalid input: "+choice);
				break;
			}
		}
		sc.close();

	
	}

}
