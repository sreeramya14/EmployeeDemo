package com.capgemini.tcc.test;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.tcc.bean.ClinicBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.IServiceClinic;
import com.capgemini.tcc.service.ServiceClinicImpl;

public class ServiceClinicImpltest {
	private IServiceClinic serviceclinic;
	

	@Before
	public void setUp() throws Exception {
		serviceclinic=new ServiceClinicImpl();
	}

	@After
	public void tearDown() throws Exception {
		serviceclinic=null;
	}

	@Test
	public final void searchtest() {
		try{
			List<ClinicBean>patientList=serviceclinic.search(1001);
			assertTrue("No such patientId",patientList.size()>0);
			
		}catch(PatientException e){
			e.printStackTrace();
		}
	}

}
